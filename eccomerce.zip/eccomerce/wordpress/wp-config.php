<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'eccomerce' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '?ed>)*MB#xwG`.03}?tvFh4kB@[@-Um:-.yFm;76zbjcgcO93I-|(^y1n,j,ivyB' );
define( 'SECURE_AUTH_KEY',  '8GOKyW{1?($u}Z9Ph9Nl-yO%}42N*i{Er(pL]HXAZNy24uudG-0(=i2Li.wfat~|' );
define( 'LOGGED_IN_KEY',    ';tnoH>c|EIu%/bjmhjg -kcl7Vc@y/X#Sk2G;0_Z<<<Jd3RyoTTI`=/zzGOJdSZh' );
define( 'NONCE_KEY',        '%Y0(1k1p.G})eP.6uX]~^QjdXrg6VEOS]We{3j`OtdbUvP1u_o^Z% F3{Gcb?e-6' );
define( 'AUTH_SALT',        'G_*gPW)%X8XBc>{v6NAY7St`fNvEx~97OT2w_[H/u)[fr|8;31#!Ds=x`#SP*Bbq' );
define( 'SECURE_AUTH_SALT', 'u4RXgE_m`oJFZ@vY{s{o_>7,L|V&cRHtA2@Tu!S}^OyzQ?p74AJ$-FTE$M63F.-i' );
define( 'LOGGED_IN_SALT',   '-MQ>XX1[Bt^3s4Dx5KE#pBxPo7c f: 5=TjQbfQ*Bk+Nc5wztm%9jb~Y_]`$_{$<' );
define( 'NONCE_SALT',       'Ph!|qX-y_1}A0LAQc:Ai7b7/w)VCUT]kjvQ?WFj([.u,A&/j!KJ2QUQ OmK`$iCb' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
